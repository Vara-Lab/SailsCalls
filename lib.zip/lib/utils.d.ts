export declare function generateUUID(): string;
